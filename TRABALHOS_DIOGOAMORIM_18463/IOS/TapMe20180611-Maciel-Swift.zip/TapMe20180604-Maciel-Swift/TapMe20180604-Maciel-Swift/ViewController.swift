//
//  ViewController.swift
//  TapMe20180604-Maciel-Swift
//
//  Created by DocAdmin on 6/4/18.
//  Copyright © 2018 ecgm. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var buttonBeep : AVAudioPlayer?
    var secondBeep : AVAudioPlayer?
    var backgroundMusic : AVAudioPlayer?
    
    //variaveis
    var count: Int = 0;
    var seconds: Int = 30;
    var timer : Timer?
    
    
//outlets
    
    @IBOutlet weak var timerlabel: UILabel!
    
    @IBOutlet weak var scorelabel: UILabel!
    
    //accoes
    @IBAction func buttonPressed(_ sender: UIButton) {
        print("Button Pressed");
        self.buttonBeep?.play()
        count += 1;
       self.scorelabel.text = "Score: \n \(self.count)"    }
    
    
    func setupAudioPlayer(withFile file: String? , andType type : String?) -> AVAudioPlayer?{
        let mainBundle = Bundle.main
        let path: String = mainBundle.path(forResource: file , ofType: type)!
        let url : URL = URL.init(fileURLWithPath: path)
        var audioPlayer : AVAudioPlayer?
        do{
            audioPlayer = try AVAudioPlayer.init(contentsOf: url)
            
        }catch{
            print(error)
            
        }
  return audioPlayer
    }

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.setupGame() ;
        view.backgroundColor=UIColor(patternImage: UIImage(named: "bg_tile.png")!)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
  
func setupGame(){
    
    self.count=0
    self.seconds = 30
    self.timerlabel.text = "Time:\(self.seconds)"
    self.scorelabel.text = "Score: \n \(self.count)"
    timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(subtractime), userInfo: nil, repeats: true)
    //Music
   self.backgroundMusic = self.setupAudioPlayer(withFile: "sonic_30", andType: "mp3")
    if(self.backgroundMusic != nil){
        self.backgroundMusic?.volume = 0.3
        self.backgroundMusic?.play()
    }
    self.buttonBeep = self.setupAudioPlayer(withFile: "ButtonTap_Sonic", andType: "wav")
    self.secondBeep = self.setupAudioPlayer(withFile: "SecondBeep", andType: "wav")
}
    
    
    
    @objc func subtractime(){
        
        self.secondBeep?.play()
        
        seconds -= 1
        timerlabel.text = "Time: \(seconds)"
        if seconds == 0{
        timer?.invalidate()
            
            
            let actionSheetController = UIAlertController(title: "Time is up", message: "you scored \(self.count)", preferredStyle: .alert)
            
            let cancelActionButton = UIAlertAction(title: "play again", style: .cancel){action -> Void in self.setupGame()}
            

            actionSheetController.addAction(cancelActionButton)
        self.present(actionSheetController,animated: true,completion: nil)

            
        }        }
}
