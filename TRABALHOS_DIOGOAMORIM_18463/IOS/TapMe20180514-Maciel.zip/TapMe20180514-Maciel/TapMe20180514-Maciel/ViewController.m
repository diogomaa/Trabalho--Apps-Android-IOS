//
//  ViewController.m
//  TapMe20180514-Maciel
//
//  Created by DocAdmin on 5/14/18.
//  Copyright © 2018 ecgm. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //NSLog(@"the view did load! ");
    
    [self setupGame]; //chamar funcao
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)buttonPressed:(id)sender {
    
    NSLog(@"Button Pressed!");
    self.count ++;
    self.scorelabel.text=[NSString stringWithFormat:@"Score \n%li",(long)self.count ];
  
}
- (void)setupGame{
    
    self.count=0;
    self.seconds=30;
    
    self.timelabel.text = [NSString stringWithFormat:@"Time:%li",(long)self.seconds];
    self.scorelabel.text =[NSString stringWithFormat:@"Score: %li ",(long)self.count];
    
    self.timers=[NSTimer scheduledTimerWithTimeInterval:1.0f  target:self selector:@selector(subtractTime) userInfo:nil repeats:YES];
}


- (void)subtractTime{
    self.seconds -- ;
    self.timelabel.text=[NSString stringWithFormat:@"Time: %li",(long)self.seconds];
    if(self.seconds==0){
        [self.timers invalidate];
        NSString *alertstring=[NSString stringWithFormat:@"YOU,SCORED %li points",(long)self.count];
        
        UIAlertController *alert =[UIAlertController alertControllerWithTitle:@"TIME IS UP" message:alertstring preferredStyle:UIAlertControllerStyleAlert] ;
        
        [alert addAction:[UIAlertAction actionWithTitle:@"play again" style:UIAlertActionStyleCancel handler:^(UIAlertAction* _Nonnull action){[self setupGame];}]];
        
        [self presentViewController:alert animated:YES completion:^{}];
        
    } }
@end
