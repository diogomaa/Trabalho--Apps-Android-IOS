//
//  AppDelegate.h
//  TapMe20180514-Maciel
//
//  Created by DocAdmin on 5/14/18.
//  Copyright © 2018 ecgm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

